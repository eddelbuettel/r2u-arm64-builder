
### Straight Up

```r
library(data.table)
db <- setDT(tools::CRAN_package_db())
bp <- db[NeedsCompilation=="yes", ] 		# binary packages

## seurat is worst at 56
##bp[, .(ndep = length(tools::package_dependencies(Package, db=db)[[1]])), by=Package][order(ndep),]

B <- bp[, .(ndep = length(tools::package_dependencies(Package, db=db)[[1]])), by=Package][order(ndep),]
## table(B$ndep)

## expensive to compute
##B[, nrevdep := length(tools::package_dependencies(Package, db=db, reverse=TRUE)[[1]]), by=Package]
#bp[1:20, .(nrevdep = length(unique(c(strsplit(`Reverse imports`, ",")[[1]], strsplit(`Reverse linking to`, ",")[[1]])))), by=Package]
bp[, let(nrevimp = 0, nrevdep = 0, nrevlt = 0)]
bp[is.na(`Reverse imports`)==FALSE, nrevimp := length(strsplit(`Reverse imports`, ",")[[1]]), by=Package]
bp[is.na(`Reverse depends`)==FALSE, nrevdep := length(strsplit(`Reverse depends`, ",")[[1]]), by=Package]
bp[is.na(`Reverse linking to`)==FALSE, nrevlt := length(strsplit(`Reverse linking to`, ",")[[1]]), by=Package]
bp[, nrev := nrevimp + nrevdep + nrevlt, by=Package]

bp[, ndep := length(tools::package_dependencies(Package, db=db)[[1]]), by=Package]

table(bp[,nrev])
```

### r2u use

```r
#cachedlog <- r2u:::.getCachedDLLogsFile()

top200 <- unique(r2u::topNCompiled(200))
db <- r2u:::.pkgenv[["db"]]

TP <- data.table(Package=top200)
P <- db[TP, on="Package"]
P <- P[!duplicated(Package),]

P[ adjdep==0, .(Package,Version,ndep,adjdep)]
P[ adjdep==1, .(Package,Version,ndep,adjdep)]
P[ adjdep==2, .(Package,Version,ndep,adjdep)]

```


#### RcppAPT

```r
library(data.table)
library(RcppAPT)
B <- data.table(getPackages("^r-(bioc|cran)-"), key="Package")
#B[, tgt := gsub(".*-\\d+.ca(\\d{4}).\\d+.*", "\\1", Version), by=Package]
B[, r2u := grepl("ca2404", Version), by=Package]
B[, vv := gsub("^\\d:", "", Version), by=Package]
B[, vvv := gsub("-\\d$", "", vv), by=Package]
B[, vvvv := gsub("-\\d\\.ca\\d{4}\\.\\d$", "", vvv), by=Package]
B[, pkgver := paste(Package, vvvv, sep="_")]
B[, let(vv = NULL, vvv = NULL, vvvv = NULL) ]
```
