
# 2024

Score is 2:2 tie

## Operated as expected

01-09 01-12

## Missed

01-10 01-11

(one Friday cheated, stated it was done when it happened on the Saturday, maybe Feb 9 - 10)

02-20 02-21 -> came on 02-22
