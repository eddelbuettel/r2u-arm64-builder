
system.time( install.packages("brms") )       # that's it, and `apt` will take care of the rest

library(brms)
