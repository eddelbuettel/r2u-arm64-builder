
system.time( install.packages("tidyverse") )	# that's it, and `apt` will take care of the rest

library(tidyverse)
