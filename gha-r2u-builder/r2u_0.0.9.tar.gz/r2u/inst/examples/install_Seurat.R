
system.time( install.packages("Seurat") )	# that's it, and `apt` will take care of the rest

library(Seurat)
