
utils::globalVariables(c("..field", "Depends", "Description", "Imports", "License", "LinkingTo", "N",
                         "NeedsCompilation", "Package", "Repository", "Suggests", "Title", "Version",
                         "deb", "package", "pkgver", "adjdep", "ndep"))
