
## jammy builds

- sp: The upstream package r-cran-sp has an epoch in its version number blocking
  pinning so a one-off build with an epoch added to this version was made
  
- gastemp: The suggested package rstantools appears to be a build dependency
  so as a one-off it was added
