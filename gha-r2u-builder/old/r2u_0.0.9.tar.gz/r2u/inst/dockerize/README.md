
## What is this ?

This directory contains a simple example for 'dockerizing' an R package. 

Use it from any R package directory as `remotes` will parse the DESCRIPTION
file (assumed from the current directory) and install all dependencies.

## Acknowledgement

This arose out of [this twitter thread started
here](https://twitter.com/philmassicotte/status/1554063172381954051) by
Philippe Massicotte with [this
follow-up](https://twitter.com/eddelbuettel/status/1554110435498119168)
containing a first version and demonstration in an animated gif.

## Author

Dirk Eddelbuettel
