
## for tools::R_user_dir("r2u"), also create a default config file
mkdir -p ~/.local/share/R/r2u 

mkdir -p /var/local/r2u/build
mkdir -p /var/local/r2u/cache
mkdir -p /var/local/r2u/ubuntu/pool

cd /mnt/
ln -s /var/local/r2u/build/ .
ln -s /var/local/r2u/cache/ .
ln -s /var/local/r2u/ubuntu .

## shows being inside Docker
ls -l /.dockerenv

